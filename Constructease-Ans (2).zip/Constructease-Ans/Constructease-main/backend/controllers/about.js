export const about = (req, res) => {
    res.send("about");
}