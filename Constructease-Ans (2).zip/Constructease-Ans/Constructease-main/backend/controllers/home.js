export const customerReq = (req, res) => {
    res.send("Home pagae!");
}
 