const Products = [
  {
    id: 1,
    pname: "Shovel",
    desc: "High Quality shovel, easy to use",
    price: "18",
    currency: "$",
    thumb: "./shovel.png",
  },
  {
    id: 2,
    pname: "hammer",
    desc: "High Quality hammer, easy to use",
    price: "6",
    currency: "$",
    thumb: "./hammer.png",
  },
  {
    id: 3,
    pname: "Screw Driver",
    desc: "High Quality screw driver, easy to use",
    price: "12",
    currency: "$",
    thumb: "./screwd.png",
  },
  {
    id: 4,
    pname: "Wrench",
    desc: "High Quality wrench, easy to use",
    price: "11",
    currency: "$",
    thumb: "./wrench.png",
  },
  {
    id: 5,
    pname: "Drill Machine",
    desc: "High Quality drill machine, easy to use",
    price: "35",
    currency: "$",
    thumb: "./drill.png",
  },
  {
    id: 6,
    pname: "Pick Axe",
    desc: "High Quality pick axe, easy to use",
    price: "21",
    currency: "$",
    thumb: "./pickaxe.png",
  }
];
export default Products;
