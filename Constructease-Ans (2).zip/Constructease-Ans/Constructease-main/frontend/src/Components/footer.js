import React from "react";
// import { Link } from "react-router-dom";
import "../Style/footer.css";
const Footer = () => (

  <div className="footer" style={{marginTop:'2rem'}}>
    <div class="row" style={{ marginRight: " calc(-0 * var(--bs-gutter-x))" }}>
      <div class="footer-col-6">
        <h2>Constructease</h2>
        <h4>Copyright © 2022 Constructease, Inc</h4>
        <h5 className="pb-2">mubeenkhalid@constructease.com</h5>
        <h5 className="pb-2">All rights reserved!</h5>
      </div>

    </div>

  </div>
);

export default Footer;
