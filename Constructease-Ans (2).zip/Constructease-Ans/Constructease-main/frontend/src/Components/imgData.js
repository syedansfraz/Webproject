const imageSlide = [
    {url:'pic1.jpg',
    title:'The Best Quality you can get!',
    body: '"Building is about getting around the obstacles that are presented to you"'
    },
    {url:'pic2.jpg',
    title:'We Serve!',
    body: '"The bitterness of poor quality remains long after the sweetness of low price is forgotten"'
    },{url:'pic3.jpg',
    title:'Your headache is now our`s',
    body: '“You can dream, create, design, and build the most wonderful place in the world. But it requires people to make the dream a reality.”'
    }
]
export default imageSlide;