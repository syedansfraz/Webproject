const Mats = [
    {
        id:1,
        pname: "Bricks Pack",
        desc:'Contains 500 bricks!',
        price: "18",
        currency: '$',
        thumb: './bricks.png'
    },
    {
        id:2,
        pname: "Stones Bag",
        desc:'High Quality hammer, easy to use',
        price: "6",
        currency: '$',
        thumb: './stones.png'
    },
    {
        id:3,
        pname: "Cement",
        desc:'High Quality screw driver, easy to use',
        price: "12",
        currency: '$',
        thumb: './cement.png'
    },
    {
        id:4,
        pname: "Steel",
        desc:'High Quality steel!',
        price: "35",
        currency: '$',
        thumb: './steel.png'
    },
    {
        id:5,
        pname: "Sand",
        desc:'High Quality sand!',
        price: "21",
        currency: '$',
        thumb: './sandbag.png'
    }
]
export default Mats;