const UserProfile = () => {




    return (
        <>
            <div className="container">
                <div className="row">
                    <div className="col-lg-6">
                        
                    </div>
                </div>
            </div>
        </>
    );
}


export default UserProfile;